Substitua estes arquivos no seu repositório do GitHub Pages. Eles assumem que `pdf.min.js`, `pdf.worker.min.js` e `ebook.pdf` já existem na raiz.
